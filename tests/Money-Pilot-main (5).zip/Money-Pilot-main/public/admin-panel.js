  // Misma configuración pública que la app (la clave "anon" es pública por diseño).
  // El panel reutiliza la sesión de MoneyPilot: no hay contraseña propia.
  const SUPABASE_URL = 'https://yhxebtkxagxowrvrqssf.supabase.co';
  const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InloeGVidGt4YWd4b3dydnJxc3NmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODc1MTc0MTMsImV4cCI6MjEwMzA5MzQxM30.Mt9vWxpTP-YnZp38qtBAuZVmMMKmIxIKyXA4ni4WZzM';
  const supa = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

  async function cabeceras() {
    const { data } = await supa.auth.getSession();
    const token = data && data.session ? data.session.access_token : null;
    if (!token) return null;
    return { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token };
  }

  (async () => {
    const sesionDiv = document.getElementById('sesion');
    const { data } = await supa.auth.getSession();
    if (data && data.session) {
      sesionDiv.textContent = 'Sesión iniciada como ' + data.session.user.email;
    } else {
      sesionDiv.textContent = '';
      const enlace = document.createElement('a');
      enlace.href = '/';
      enlace.textContent = 'Inicia sesión en MoneyPilot con tu cuenta de administrador';
      sesionDiv.appendChild(enlace);
      sesionDiv.appendChild(document.createTextNode(' y vuelve a esta página.'));
    }
  })();

  let tipo = 'noticia';

  const btnNoticia = document.getElementById('btnNoticia');
  const btnTesis = document.getElementById('btnTesis');
  const btnGuia = document.getElementById('btnGuia');

  btnNoticia.onclick = () => { tipo = 'noticia'; btnNoticia.classList.add('activo'); btnTesis.classList.remove('activo'); btnGuia.classList.remove('activo'); };
  btnTesis.onclick = () => { tipo = 'tesis'; btnTesis.classList.add('activo'); btnNoticia.classList.remove('activo'); btnGuia.classList.remove('activo'); };
  btnGuia.onclick = () => { tipo = 'guia'; btnGuia.classList.add('activo'); btnNoticia.classList.remove('activo'); btnTesis.classList.remove('activo'); };

  document.getElementById('generar').onclick = async () => {
    const tema = document.getElementById('tema').value.trim();
    const cta_texto = document.getElementById('ctaTexto').value.trim();
    const cta_enlace_texto = document.getElementById('ctaEnlaceTexto').value.trim();
    const cta_enlace_url = document.getElementById('ctaEnlaceUrl').value.trim();
    const estado = document.getElementById('estado');
    const boton = document.getElementById('generar');

    const headers = await cabeceras();
    if (!headers) { alert('Primero inicia sesión en MoneyPilot como administrador'); return; }
    if (!tema) { alert('Escribe un ticker o tema'); return; }

    boton.disabled = true;
    estado.className = 'cargando';
    estado.textContent = 'Generando contenido con Gemini… esto puede tardar unos 15 segundos.';

    try {
      const res = await fetch('/api/generar-inversion', {
        method: 'POST',
        headers,
        body: JSON.stringify({ tema, tipo, cta_texto, cta_enlace_texto, cta_enlace_url }),
      });
      const data = await res.json();

      if (!res.ok) {
        estado.className = 'error';
        estado.textContent = 'Error: ' + (data.error || 'algo falló') + (data.detalle ? (' — ' + JSON.stringify(data.detalle)) : '');
      } else {
        estado.className = 'ok';
        estado.textContent = '✅ Contenido generado: "' + data.post.title + '". Se publicará solo en el próximo despliegue (unos minutos).';
        document.getElementById('tema').value = '';
        document.getElementById('ctaTexto').value = '';
        document.getElementById('ctaEnlaceTexto').value = '';
        document.getElementById('ctaEnlaceUrl').value = '/';
      }
    } catch (err) {
      estado.className = 'error';
      estado.textContent = 'Error de conexión: ' + err.message;
    } finally {
      boton.disabled = false;
    }
  };

  document.getElementById('cargarPosts').onclick = async () => {
    const listaEstado = document.getElementById('listaEstado');
    const contenedor = document.getElementById('listaPosts');

    const headers = await cabeceras();
    if (!headers) { alert('Primero inicia sesión en MoneyPilot como administrador'); return; }

    listaEstado.textContent = 'Cargando…';
    contenedor.innerHTML = '';
    try {
      const res = await fetch('/api/posts-admin', {
        method: 'POST',
        headers,
        body: JSON.stringify({ action: 'list' }),
      });
      const data = await res.json();
      if (!res.ok) { listaEstado.textContent = 'Error: ' + (data.error || 'algo falló'); return; }

      if (!data.posts.length) {
        listaEstado.textContent = 'No hay artículos.';
        return;
      }
      listaEstado.textContent = '';

      data.posts.forEach(p => {
        const card = document.createElement('div');
        card.className = 'post-card';

        const inputTexto = document.createElement('textarea');
        inputTexto.rows = 2;
        inputTexto.value = p.cta_texto || '';
        inputTexto.placeholder = '(usando el mensaje por defecto)';

        const inputEnlaceTexto = document.createElement('input');
        inputEnlaceTexto.type = 'text';
        inputEnlaceTexto.value = p.cta_enlace_texto || '';

        const inputEnlaceUrl = document.createElement('input');
        inputEnlaceUrl.type = 'text';
        inputEnlaceUrl.value = p.cta_enlace_url || '/';

        const btnGuardar = document.createElement('button');
        btnGuardar.className = 'guardar-fila';
        btnGuardar.textContent = 'Guardar';
        btnGuardar.onclick = async () => {
          btnGuardar.disabled = true;
          btnGuardar.textContent = '...';
          try {
            const r = await fetch('/api/posts-admin', {
              method: 'POST',
              headers: (await cabeceras()) || headers,
              body: JSON.stringify({
                action: 'update',
                id: p.id,
                cta_texto: inputTexto.value,
                cta_enlace_texto: inputEnlaceTexto.value,
                cta_enlace_url: inputEnlaceUrl.value,
              }),
            });
            const d = await r.json();
            btnGuardar.textContent = r.ok ? '✅ Guardado' : 'Error';
            if (!r.ok) console.error(d);
          } catch (e) {
            btnGuardar.textContent = 'Error';
          } finally {
            setTimeout(() => { btnGuardar.disabled = false; btnGuardar.textContent = 'Guardar'; }, 1800);
          }
        };

        const tituloDiv = document.createElement('div');
        tituloDiv.className = 'titulo';
        tituloDiv.textContent = p.title;
        const seccionDiv = document.createElement('div');
        seccionDiv.className = 'seccion';
        seccionDiv.textContent = p.categoria_seccion;
        const labelTexto = document.createElement('label');
        labelTexto.textContent = 'Mensaje del CTA';
        card.appendChild(tituloDiv);
        card.appendChild(seccionDiv);
        card.appendChild(labelTexto);
        card.appendChild(inputTexto);

        const labelEnlaceTexto = document.createElement('label');
        labelEnlaceTexto.textContent = 'Texto del enlace';
        card.appendChild(labelEnlaceTexto);
        card.appendChild(inputEnlaceTexto);

        const labelEnlaceUrl = document.createElement('label');
        labelEnlaceUrl.textContent = 'A dónde lleva el enlace';
        card.appendChild(labelEnlaceUrl);
        card.appendChild(inputEnlaceUrl);

        card.appendChild(btnGuardar);
        contenedor.appendChild(card);
      });
    } catch (err) {
      listaEstado.textContent = 'Error de conexión: ' + err.message;
    }
  };
